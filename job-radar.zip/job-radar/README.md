# Job Radar

Search remote jobs on three public job boards (We Work Remotely, Working Nomads, Jobicy). Every posting gets an automated trust check with one of these labels and a one line reason: Looks fine, Check first, Likely scam. Results are sorted newest first, show when they were last checked, and each has a copy link button.

It uses the Mino web agent (the docs now call it the TinyFish Agent API): a URL plus a plain language goal returns structured JSON.

## How it works

1. The visitor types a job title. The server validates it and starts one agent run per board (`POST /v1/automation/run-async`).
2. The browser polls `/api/status`. Each poll reads finished runs (`GET /v1/runs/{id}`), cleans the listings, and shows them.
3. When all boards have answered, the newest listings each get a second agent run that reads the posting page and reports facts (company website listed, how to apply, pay shown, asks for money or documents).
4. `lib/trust.js` scores those facts and picks the label. The agent reports facts. Our own code decides the label.

## Run it on your computer

You need Node 20 or newer.

```
npm install
cp .env.example .env        # then open .env and add your TINYFISH_API_KEY
npm run dev                 # http://localhost:3000
npm test                    # 23 tests, no API key or network needed
```

`npm run dev:mock` runs the site against a fake agent so you can click around for free. Every result in that mode is made up and labelled "(mock)". Never use it for a real demo.

## Put it on Vercel

1. Create a new API key at TinyFish. Do not reuse any key that has been pasted into a chat. Rotate it if it has.
2. The contact email in `public/privacy.html` and `public/terms.html` is already filled in. Change it there if you want a different public address.
3. Run `npm run predeploy`. It fails if a placeholder is left in, a key looks committed, or a rule from the brief is broken.
4. Push to a private GitHub repo. `.env` is in `.gitignore`. Check `git status` shows no `.env` before you commit.
5. In Vercel choose Add New Project and import the repo. Framework preset: Other. Leave build and output settings empty. Vercel serves `public/` and runs the files in `api/` as functions.
6. Create a free Redis database at Upstash (Vercel Marketplace has a one click option). The code reads either `UPSTASH_REDIS_REST_URL` and `UPSTASH_REDIS_REST_TOKEN`, or `KV_REST_API_URL` and `KV_REST_API_TOKEN`. Use whichever your integration creates.
7. In Project Settings, Environment Variables, add:
   - `TINYFISH_API_KEY`
   - `RATE_LIMIT_SALT` (any long random string, for example the output of `openssl rand -hex 32`)
   - the Redis variables, if the integration did not add them
8. Deploy, open the site, and run one search. Watch your TinyFish usage for the first few searches, then raise or lower `DAILY_RUN_CAP` to match what you are willing to spend per day.

In production the site refuses to run if the Redis store, the salt or the API key is missing. That is deliberate, so a misconfigured deploy cannot spend credits without limits.

## Cost controls

| Setting | Default | What it does |
| --- | --- | --- |
| `SEARCHES_PER_IP_PER_HOUR` | 3 | Per visitor limit on new searches |
| `DAILY_RUN_CAP` | 40 | Hard cap on agent runs the whole site can start per day (about 3 full searches) |
| `TRUST_CHECK_LIMIT` | 10 | Only the newest N listings get a trust check |
| `RESULTS_PER_BOARD` | 8 | Listings requested per board |
| `SEARCH_ENABLED` | true | Set to false to switch search off instantly |

The agent is billed at $0.016 per step plus a small browser charge. Board runs took 6 to 8 steps in testing, so a full search of 3 boards plus 10 checks costs very roughly $0.50 to $1.00 (check runs were not measured, so treat that as an estimate). Fetch and Search are free, the agent is not. At the default cap the most the site can spend in a day is about $3 to $4.

A search starts 3 board runs plus up to 10 check runs. Results are cached for 30 minutes (only when every board answered) and each posting's check is cached for 24 hours, so repeats cost nothing. Each run is also limited by time (120 seconds for boards, 90 for checks).

## Security notes

- The API key lives only in a server environment variable and is used only in `lib/mino.js`. It is never sent to the browser.
- Visitors cannot send URLs. Board URLs are built on the server, and every URL is checked against the approved board list (exact hostname, https only, no credentials, no odd ports) before it goes to the agent. Links coming back from the agent are checked the same way and dropped if they fail.
- The one thing a visitor types (the job title) is limited to letters, numbers and basic punctuation, 2 to 60 characters. It is placed between markers in the agent goal, and the goal tells the agent to ignore instructions in it.
- Everything scraped is treated as untrusted. The server strips tags, hidden characters and dash characters and caps lengths. The browser only ever uses `textContent`, never `innerHTML`. A strict Content Security Policy blocks inline scripts.
- Rate limiting uses a salted hash of the visitor address, so raw IP addresses are never stored.
- Requests must be POST, JSON, same origin and under 2 KB.
- Logs contain error codes only. No search text, keys or addresses.
- The agent is never given login credentials, a browser profile or the vault, and the goals tell it not to log in or fill forms.
- Errors from the agent become plain messages. A board that fails does not stop the others.

## Folder map

```
api/search.js        starts a search
api/status.js        moves a search forward and returns what is known
lib/boards.js        the approved boards and the agent goals
lib/mino.js          the only code that talks to the Agent API
lib/jobs.js          search lifecycle, cleaning, caching
lib/trust.js         facts to label and reason
lib/allowlist.js     URL checks
lib/sanitize.js      input and scraped text cleaning
lib/pay.js           pay checks     lib/posted.js   date parsing
lib/store.js         Redis or in-memory     lib/ratelimit.js   limits and budget
public/              pages, styles, script, favicon
scripts/             dev server, mock mode, predeploy check
test/                23 tests including a fake agent end to end
```

## Add a board

Add an entry to `BOARDS` in `lib/boards.js` with its domains, a URL builder and a hint. The allowlist, parsing and checks pick it up automatically. Check the board's robots.txt and terms first, and run its goal once by hand to see what comes back.

See `HALF-BUILT.md` for what is not finished or not verified.
