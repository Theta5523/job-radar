'use strict';

// Run before deploying: npm run predeploy
// Fails if a placeholder is left in, a secret looks committed, or a rule from
// the brief is broken.

const fs = require('node:fs');
const path = require('node:path');

const root = path.join(__dirname, '..');
const problems = [];
const SKIP = new Set(['node_modules', '.git', '.vercel']);

function walk(dir, out = []) {
  for (const name of fs.readdirSync(dir)) {
    if (SKIP.has(name)) continue;
    const full = path.join(dir, name);
    if (fs.statSync(full).isDirectory()) walk(full, out);
    else out.push(full);
  }
  return out;
}

const files = walk(root);
const textFiles = files.filter((f) => /\.(js|json|html|css|md|svg|example)$/.test(f) || path.basename(f) === '.gitignore');
const rel = (f) => path.relative(root, f);

for (const f of textFiles) {
  const text = fs.readFileSync(f, 'utf8');
  if (/sk-tinyfish-[A-Za-z0-9_-]{10,}/.test(text)) problems.push(`Possible API key in ${rel(f)}`);
  if (/[\u2013\u2014]/.test(text) && !rel(f).startsWith('test')) problems.push(`Dash character (en or em) in ${rel(f)}`);
  if (rel(f).startsWith('public') && text.includes('YOUR_CONTACT_EMAIL')) {
    problems.push(`Replace YOUR_CONTACT_EMAIL in ${rel(f)}`);
  }
}

const ignore = fs.readFileSync(path.join(root, '.gitignore'), 'utf8');
if (!/^\.env$/m.test(ignore)) problems.push('.env is not in .gitignore');
if (files.some((f) => path.basename(f) === '.env')) {
  console.log('Note: a local .env file exists. It is ignored by git, so it will not be committed.');
}

const vercel = JSON.parse(fs.readFileSync(path.join(root, 'vercel.json'), 'utf8'));
const hdrs = JSON.stringify(vercel.headers || []);
for (const needed of ['Strict-Transport-Security', 'Content-Security-Policy']) {
  if (!hdrs.includes(needed)) problems.push(`vercel.json is missing ${needed}`);
}

if (problems.length) {
  console.error('Predeploy check failed:\n- ' + problems.join('\n- '));
  process.exit(1);
}
console.log('Predeploy check passed.');
