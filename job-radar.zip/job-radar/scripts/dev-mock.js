'use strict';

// Runs the site locally against a FAKE Mino server, so you can click through the
// interface without spending credits. Every result here is made up and labelled
// "(mock)". Never use this mode for a real demo. Usage: npm run dev:mock

const http = require('node:http');

const LISTINGS = {
  wwr: [
    { title: 'Associate Product Manager (mock)', company: 'Example Co (mock)', link: 'https://weworkremotely.com/remote-jobs/mock-example-apm', posted: '2d', pay: 'USD 60k-80k/year' },
    { title: 'Product Associate (mock)', company: 'Sample Ltd (mock)', link: 'https://weworkremotely.com/remote-jobs/mock-sample-pa', posted: '5 hours ago', pay: null },
  ],
  wn: [
    { title: 'Quick Cash Assistant (mock)', company: 'Fast Money Inc (mock)', link: 'https://www.workingnomads.com/jobs/mock-scam', posted: '1 day ago', pay: '$5,000 a week, no experience needed' },
  ],
};
const FACTS = {
  example: { company_name: 'Example Co', company_website_domain: 'example.com', has_company_profile_on_this_site: true, apply_method: 'board_apply_button', apply_email_domain: null, pay_text: 'USD 60k-80k/year', asks_for_payment: false, asks_for_personal_documents: false, evidence: null },
  sample: { company_name: null, company_website_domain: null, has_company_profile_on_this_site: false, apply_method: 'unknown', apply_email_domain: null, pay_text: null, asks_for_payment: false, asks_for_personal_documents: false, evidence: null },
  scam: { company_name: 'Fast Money Inc', company_website_domain: null, has_company_profile_on_this_site: false, apply_method: 'messaging_app', apply_email_domain: null, pay_text: null, asks_for_payment: true, asks_for_personal_documents: false, evidence: 'Pay a $50 starter kit fee' },
};

const runs = new Map();
const mock = http.createServer((req, res) => {
  let body = '';
  req.on('data', (c) => (body += c));
  req.on('end', () => {
    const json = (s, o) => { res.writeHead(s, { 'content-type': 'application/json' }); res.end(JSON.stringify(o)); };
    if (req.method === 'POST' && req.url === '/v1/automation/run-async') {
      const id = `run_mock_${String(runs.size + 1).padStart(4, '0')}`;
      runs.set(id, { at: Date.now(), url: new URL(JSON.parse(body).url) });
      return json(200, { run_id: id, error: null });
    }
    const m = req.url.match(/^\/v1\/runs\/(.+)$/);
    const r = m && runs.get(m[1]);
    if (!r) return json(404, {});
    if (Date.now() - r.at < 6000) return json(200, { run_id: m[1], status: 'RUNNING' });
    const u = r.url;
    const done = (result) => json(200, { run_id: m[1], status: 'COMPLETED', result });
    if (u.hostname === 'weworkremotely.com' && u.pathname.includes('search')) return done({ listings: LISTINGS.wwr });
    if (u.hostname === 'www.workingnomads.com' && u.pathname === '/jobs') return done({ listings: LISTINGS.wn });
    if (u.hostname === 'jobicy.com') return json(200, { run_id: m[1], status: 'FAILED', result: null, error: { code: 'SITE_BLOCKED' } });
    for (const key of Object.keys(FACTS)) if (u.pathname.includes(key)) return done(FACTS[key]);
    return done({ status: 'failure' });
  });
});

mock.listen(0, '127.0.0.1', () => {
  process.env.TINYFISH_API_KEY = 'mock-key';
  process.env.TINYFISH_BASE_URL = `http://127.0.0.1:${mock.address().port}`;
  console.log('MOCK MODE: every result is fake. Do not use this for a real demo.');
  require('./dev-server');
});
