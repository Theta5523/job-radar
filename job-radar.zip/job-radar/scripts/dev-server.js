'use strict';

// Local development server. Serves /public and routes /api/* to the same
// handler files Vercel runs in production. Usage: npm run dev

const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');

const root = path.join(__dirname, '..');

// Minimal .env loader so no extra dependency is needed.
const envFile = path.join(root, '.env');
if (fs.existsSync(envFile)) {
  for (const line of fs.readFileSync(envFile, 'utf8').split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/);
    if (m && process.env[m[1]] === undefined) process.env[m[1]] = m[2].replace(/^["']|["']$/g, '');
  }
}

const vercel = JSON.parse(fs.readFileSync(path.join(root, 'vercel.json'), 'utf8'));
const globalHeaders = (vercel.headers.find((h) => h.source === '/(.*)') || { headers: [] }).headers;
const pub = path.join(root, 'public');
const routes = {
  '/api/search': require('../api/search'),
  '/api/status': require('../api/status'),
};
const TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
};

const server = http.createServer(async (req, res) => {
  for (const h of globalHeaders) {
    // Strict-Transport-Security is only meaningful over https.
    if (h.key !== 'Strict-Transport-Security') res.setHeader(h.key, h.value);
  }
  const url = new URL(req.url, 'http://localhost');
  const handler = routes[url.pathname];
  if (handler) {
    try {
      await handler(req, res);
    } catch {
      res.statusCode = 500;
      res.end('{"error":"Something went wrong."}');
    }
    return;
  }

  let rel = decodeURIComponent(url.pathname);
  if (rel === '/') rel = '/index.html';
  else if (!path.extname(rel)) rel += '.html';
  const file = path.join(pub, rel);
  if (!file.startsWith(pub + path.sep) || !fs.existsSync(file) || !fs.statSync(file).isFile()) {
    res.statusCode = 404;
    res.setHeader('Content-Type', 'text/plain; charset=utf-8');
    res.end('Not found');
    return;
  }
  res.setHeader('Content-Type', TYPES[path.extname(file)] || 'application/octet-stream');
  fs.createReadStream(file).pipe(res);
});

const port = Number(process.env.PORT) || 3000;
server.listen(port, '127.0.0.1', () => {
  console.log(`Job Radar running at http://localhost:${port}`);
  if (!process.env.TINYFISH_API_KEY) console.log('TINYFISH_API_KEY is not set. Copy .env.example to .env and add it.');
});
