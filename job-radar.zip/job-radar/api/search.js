'use strict';

const store = require('../lib/store');
const settings = require('../lib/settings');
const { send, guard, ensureConfigured, readJson, HttpError } = require('../lib/http');
const { cleanTitleInput } = require('../lib/sanitize');
const { hit } = require('../lib/ratelimit');
const { startSearch, publicView } = require('../lib/jobs');
const { sha256 } = require('../lib/util');
const { logError } = require('../lib/log');
const { userMessage } = require('../lib/mino');

// POST /api/search  { title }
// Starts one reader run per approved board and returns a job id to poll.
module.exports = async function handler(req, res) {
  try {
    if (!guard(req, res)) return;
    if (!settings.enabled()) {
      return send(res, 503, { error: 'Search is switched off right now. Please try again later.' });
    }
    if (!ensureConfigured(res)) return;

    const body = await readJson(req);
    const parsed = cleanTitleInput(body && body.title);
    if (!parsed.ok) return send(res, 400, { error: parsed.error });

    const limit = await hit(req, 'search', settings.searchesPerIpPerHour(), 3600);
    if (!limit.allowed) {
      return send(
        res,
        429,
        { error: 'You have reached the search limit for this hour. Please try again later.' },
        { 'Retry-After': limit.retryAfter }
      );
    }

    // The cache key is a salted hash, so search text is never stored.
    const titleHash = sha256(`${process.env.RATE_LIMIT_SALT || 'dev-only-salt'}|${parsed.value.toLowerCase()}`);
    const cached = await store.get(`cache:${titleHash}`);
    if (cached) return send(res, 200, { cached: true, ...cached });

    const out = await startSearch(parsed.value, titleHash);
    if (out.error === 'budget') {
      return send(res, 503, { error: 'The daily search budget has been used up. Please try again tomorrow.' });
    }
    if (out.error === 'all_failed') {
      return send(res, 502, { error: out.message || userMessage('failed') });
    }
    return send(res, 202, { jobId: out.job.id, ...publicView(out.job) });
  } catch (err) {
    if (err instanceof HttpError) return send(res, err.status, { error: err.message });
    logError('search_unhandled');
    return send(res, 500, { error: 'Something went wrong on our side. Please try again.' });
  }
};
