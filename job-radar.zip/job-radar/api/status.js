'use strict';

const store = require('../lib/store');
const { send, guard, ensureConfigured, readJson, HttpError } = require('../lib/http');
const { hit } = require('../lib/ratelimit');
const { advance, publicView } = require('../lib/jobs');
const { logError } = require('../lib/log');

// POST /api/status  { jobId }
// Moves the job forward (reads finished runs, starts trust checks) and returns
// what is known so far. The browser calls this every few seconds.
module.exports = async function handler(req, res) {
  try {
    if (!guard(req, res)) return;
    if (!ensureConfigured(res)) return;

    const body = await readJson(req);
    const jobId = body && body.jobId;
    if (typeof jobId !== 'string' || !/^[a-f0-9]{32}$/.test(jobId)) {
      return send(res, 400, { error: 'That search id is not valid.' });
    }

    const limit = await hit(req, 'status', 240, 600);
    if (!limit.allowed) {
      return send(res, 429, { error: 'Too many requests. Please slow down.' }, { 'Retry-After': limit.retryAfter });
    }

    let job = await store.get(`job:${jobId}`);
    if (!job) return send(res, 404, { error: 'This search expired. Please run it again.' });

    if (job.phase !== 'done') {
      // Only one request at a time moves a job forward.
      const gotLock = await store.setIfAbsent(`lock:${jobId}`, '1', 10);
      if (gotLock) {
        try {
          job = await advance(job);
        } finally {
          await store.del(`lock:${jobId}`);
        }
      }
    }
    return send(res, 200, publicView(job));
  } catch (err) {
    if (err instanceof HttpError) return send(res, err.status, { error: err.message });
    logError('status_unhandled');
    return send(res, 500, { error: 'Something went wrong on our side. Please try again.' });
  }
};
