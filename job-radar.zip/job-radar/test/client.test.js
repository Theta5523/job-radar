const { JSDOM } = require('jsdom');
const fs = require('fs');
const root = require('path').join(__dirname, '..', 'public') + '/';
const html = fs.readFileSync(root + 'index.html', 'utf8').replace(/<script src="\/app.js" defer><\/script>/, '');
const js = fs.readFileSync(root + 'app.js', 'utf8');

const hostile = {
  phase: 'done', checkedAt: '2026-10-25T02:00:00.000Z',
  boards: [
    { name: 'We Work Remotely', status: 'done', count: 2, error: null },
    { name: 'Jobicy', status: 'failed', count: 0, error: 'The board blocked the automated read.' },
  ],
  listings: [
    { id: 'a', board: 'We Work Remotely', title: '<img src=x onerror="window.pwned=1">APM', company: '<b>Acme</b>', link: 'https://weworkremotely.com/remote-jobs/a', posted: '2d', pay: null, trust: { label: 'Looks fine', reason: 'Company website listed (acme.com).' } },
    { id: 'b', board: 'Jobicy', title: 'Bad link', company: null, link: 'javascript:window.pwned=2', posted: null, pay: '$1', trust: { label: 'Likely scam', reason: 'x' } },
  ],
};

(async () => {
  const dom = new JSDOM(html, { runScripts: 'outside-only', url: 'http://localhost/' });
  const w = dom.window;
  const calls = [];
  w.fetch = async (path, opts) => {
    calls.push(path);
    const ok = (obj, status = 200) => ({ ok: status < 400, status, json: async () => obj });
    if (path === '/api/search') return ok({ jobId: 'a'.repeat(32), phase: 'listing', boards: hostile.boards.map((b) => ({ ...b, status: 'running' })), listings: [], checkedAt: null }, 202);
    return ok(hostile);
  };
  w.navigator.clipboard = { writeText: async (t) => { w.__copied = t; } };
  // speed up polling
  const realSetTimeout = w.setTimeout;
  w.setTimeout = (fn, ms) => realSetTimeout(fn, ms === 4000 ? 5 : ms);
  w.eval(js);

  w.document.getElementById('search-form').dispatchEvent(new w.Event('submit', { cancelable: true, bubbles: true }));
  for (let i = 0; i < 60 && !w.document.querySelector('.job'); i++) await new Promise((r) => setTimeout(r, 20));

  const d = w.document;
  const jobs = d.querySelectorAll('.job');
  const out = [];
  const check = (name, cond) => { out.push((cond ? 'PASS ' : 'FAIL ') + name); if (!cond) process.exitCode = 1; };
  check('two listings rendered', jobs.length === 2);
  check('no injected img element', d.querySelectorAll('.jobs img, .jobs b, .jobs script').length === 0);
  check('hostile title shown as plain text', jobs[0].querySelector('.job-title').textContent.includes('<img src=x'));
  check('script never ran', w.pwned === undefined);
  check('javascript: link gets no Open button', jobs[1].querySelector('a') === null);
  check('safe link opens in new tab with noopener', (() => { const a = jobs[0].querySelector('a.btn'); return a && a.target === '_blank' && /noopener/.test(a.rel) && a.href.startsWith('https://weworkremotely.com/'); })());
  check('verdict label and reason shown', jobs[0].querySelector('.verdict').textContent.startsWith('Looks fine. Company website'));
  check('trust drives data attribute', jobs[0].dataset.trust === 'fine' && jobs[1].dataset.trust === 'scam');
  check('missing pay shows Not shown', jobs[0].textContent.includes('Not shown'));
  check('failed board message shown', d.getElementById('status').textContent.includes('blocked the automated read'));
  check('last checked time shown', /Last checked/.test(d.getElementById('results-meta').textContent));
  check('button re-enabled after done', d.getElementById('search-button').disabled === false);
  jobs[0].querySelector('button').click();
  await new Promise((r) => setTimeout(r, 50));
  check('copy link copies the exact link', w.__copied === 'https://weworkremotely.com/remote-jobs/a');
  check('copy button confirms', jobs[0].querySelector('button').textContent === 'Copied');
  // server error path
  w.fetch = async () => ({ ok: false, status: 429, json: async () => ({ error: 'You have reached the search limit for this hour. Please try again later.' }) });
  d.getElementById('search-form').dispatchEvent(new w.Event('submit', { cancelable: true, bubbles: true }));
  await new Promise((r) => setTimeout(r, 100));
  check('429 shows a clear message', d.getElementById('error').textContent.includes('search limit') && !d.getElementById('error').hidden);
  console.log(out.join('\n'));
})();
