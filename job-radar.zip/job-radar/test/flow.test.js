'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const http = require('node:http');

const KEY = 'test-key-1234567890';
process.env.TINYFISH_API_KEY = KEY;
process.env.RATE_LIMIT_SALT = 'test-salt';
process.env.NODE_ENV = 'test';
delete process.env.UPSTASH_REDIS_REST_URL;
delete process.env.KV_REST_API_URL;

const store = require('../lib/store');
const search = require('../api/search');
const status = require('../api/status');
const { ALL_DOMAINS } = require('../lib/allowlist');

// ---------- fake Mino server ----------

const WWR = [
  { title: 'Associate Product Manager', company: 'Acme', link: 'https://weworkremotely.com/remote-jobs/acme-apm', posted: '3d', pay: 'USD 60k\u201380k/year' },
  { title: '<img src=x onerror=alert(1)>Product Analyst', company: '<script>alert(1)</script>Globex', link: 'https://weworkremotely.com/remote-jobs/globex-analyst', posted: '1d', pay: null },
  { title: 'Off domain', company: 'Evil', link: 'https://evil.example.com/job', posted: '1d', pay: null },
  { title: 'Lookalike domain', company: 'Evil', link: 'https://weworkremotely.com.evil.com/x', posted: '1d', pay: null },
  { title: 'Insecure link', company: 'Evil', link: 'http://weworkremotely.com/remote-jobs/insecure', posted: '1d', pay: null },
  { title: 'Wrong board link', company: 'Evil', link: 'https://jobicy.com/jobs/1-x', posted: '1d', pay: null },
];
const WN = [
  { title: 'Fast Cash Assistant', company: 'Quick Co', link: 'https://www.workingnomads.com/jobs/scam-fast-cash', posted: '9 hours ago', pay: '$5,000 a week, no experience needed' },
];
const FACTS = {
  good: { company_name: 'Acme', company_website_domain: 'acme.com', has_company_profile_on_this_site: true, apply_method: 'board_apply_button', apply_email_domain: null, pay_text: 'USD 60k-80k/year', asks_for_payment: false, asks_for_personal_documents: false, evidence: null },
  vague: { company_name: null, company_website_domain: null, has_company_profile_on_this_site: false, apply_method: 'unknown', apply_email_domain: null, pay_text: null, asks_for_payment: false, asks_for_personal_documents: false, evidence: null },
  scam: { company_name: 'Quick Co', company_website_domain: null, has_company_profile_on_this_site: false, apply_method: 'messaging_app', apply_email_domain: null, pay_text: null, asks_for_payment: true, asks_for_personal_documents: true, evidence: 'Send a copy of your passport and a $50 fee' },
};

function startMock(opts = {}) {
  const runs = new Map();
  const log = [];
  const server = http.createServer((req, res) => {
    let body = '';
    req.on('data', (c) => (body += c));
    req.on('end', async () => {
      const entry = { method: req.method, url: req.url, key: req.headers['x-api-key'], body: body ? JSON.parse(body) : null };
      log.push(entry);
      const json = (status, obj) => {
        res.writeHead(status, { 'content-type': 'application/json' });
        res.end(JSON.stringify(obj));
      };
      if (opts.hang) return; // never answer, to test timeouts
      if (req.method === 'POST' && req.url === '/v1/automation/run-async') {
        if (opts.queueStatus) return json(opts.queueStatus, { error: { code: 'X', message: 'nope' } });
        const id = `run_${String(runs.size + 1).padStart(4, '0')}_abcdef`;
        runs.set(id, { polls: 0, req: entry.body });
        return json(200, { run_id: id, error: null });
      }
      const m = req.url.match(/^\/v1\/runs\/(.+)$/);
      if (req.method === 'GET' && m) {
        const r = runs.get(m[1]);
        if (!r) return json(404, { error: { code: 'NOT_FOUND' } });
        r.polls += 1;
        if (r.polls < 2) return json(200, { run_id: m[1], status: 'RUNNING' });
        const u = new URL(r.req.url);
        if (u.hostname === 'weworkremotely.com' && u.pathname.includes('search')) return json(200, { run_id: m[1], status: 'COMPLETED', result: { listings: WWR } });
        if (u.hostname === 'www.workingnomads.com' && u.pathname === '/jobs') return json(200, { run_id: m[1], status: 'COMPLETED', result: { listings: WN } });
        if (u.hostname === 'jobicy.com' && opts.jobicyOk && u.pathname === '/jobs') return json(200, { run_id: m[1], status: 'COMPLETED', result: { listings: [{ title: 'Product Associate', company: 'Acme', link: 'https://jobicy.com/jobs/1-acme-product-associate', posted: '2d', pay: null }] } });
        if (u.hostname === 'jobicy.com' && u.pathname.includes('acme')) return json(200, { run_id: m[1], status: 'COMPLETED', result: FACTS.good });
        if (u.hostname === 'jobicy.com') return json(200, { run_id: m[1], status: 'FAILED', result: null, error: { code: 'SITE_BLOCKED', message: 'blocked' } });
        if (u.pathname.includes('acme')) return json(200, { run_id: m[1], status: 'COMPLETED', result: FACTS.good });
        if (u.pathname.includes('globex')) return json(200, { run_id: m[1], status: 'COMPLETED', result: FACTS.vague });
        if (u.pathname.includes('scam')) return json(200, { run_id: m[1], status: 'COMPLETED', result: FACTS.scam });
        return json(200, { run_id: m[1], status: 'COMPLETED', result: { status: 'failure' } });
      }
      return json(404, {});
    });
  });
  return new Promise((resolve) =>
    server.listen(0, '127.0.0.1', () => resolve({ server, log, url: `http://127.0.0.1:${server.address().port}` }))
  );
}

// ---------- fake request and response ----------

function call(handler, body, { ip = '203.0.113.7', headers = {} } = {}) {
  const req = {
    method: 'POST',
    headers: { 'content-type': 'application/json', host: 'localhost:3000', 'x-real-ip': ip, ...headers },
    body,
  };
  return new Promise((resolve, reject) => {
    const res = {
      statusCode: 200,
      headers: {},
      setHeader(k, v) { this.headers[k.toLowerCase()] = v; },
      end(s) { resolve({ status: this.statusCode, headers: this.headers, text: s, json: JSON.parse(s) }); },
    };
    handler(req, res).catch(reject);
  });
}

async function runToCompletion(jobId, ip) {
  let last;
  for (let i = 0; i < 20; i += 1) {
    last = await call(status, { jobId }, { ip });
    if (last.json.phase === 'done') return last;
  }
  throw new Error('job did not finish');
}

test.beforeEach(() => {
  store.resetMemoryForTests();
  delete process.env.DAILY_RUN_CAP;
  delete process.env.SEARCHES_PER_IP_PER_HOUR;
  delete process.env.MINO_TIMEOUT_MS;
  process.env.NODE_ENV = 'test';
});

test('full search: queues board runs, checks listings, sanitises, labels, sorts', async () => {
  const mock = await startMock();
  process.env.TINYFISH_BASE_URL = mock.url;
  try {
    const started = await call(search, { title: 'Associate Product Manager' });
    assert.equal(started.status, 202);
    assert.match(started.json.jobId, /^[a-f0-9]{32}$/);

    const done = await runToCompletion(started.json.jobId);
    const view = done.json;

    // boards: two worked, one blocked, and the page still rendered
    const byName = Object.fromEntries(view.boards.map((b) => [b.name, b]));
    assert.equal(byName['We Work Remotely'].status, 'done');
    assert.equal(byName['Working Nomads'].status, 'done');
    assert.equal(byName['Jobicy'].status, 'failed');
    assert.match(byName['Jobicy'].error, /blocked/i);

    // off-domain, lookalike, http and wrong-board links were dropped
    const titles = view.listings.map((l) => l.title);
    assert.deepEqual(titles.sort(), ['Associate Product Manager', 'Fast Cash Assistant', 'Product Analyst'].sort());

    // hostile markup is gone
    const all = JSON.stringify(view);
    assert.ok(!/[<>]/.test(all.replace(/"/g, '')), 'no angle brackets in output');
    assert.ok(!all.includes('onerror'));
    assert.ok(!/[\u2013\u2014]/.test(all), 'no en or em dashes in output');

    // newest first (9 hours, 1 day, 3 days)
    assert.deepEqual(view.listings.map((l) => l.title), ['Fast Cash Assistant', 'Product Analyst', 'Associate Product Manager']);

    // trust labels
    const label = Object.fromEntries(view.listings.map((l) => [l.title, l.trust.label]));
    assert.equal(label['Associate Product Manager'], 'Looks fine');
    assert.equal(label['Product Analyst'], 'Check first');
    assert.equal(label['Fast Cash Assistant'], 'Likely scam');
    for (const l of view.listings) assert.ok(l.trust.reason.length > 5 && !l.trust.reason.includes('\n'));

    assert.ok(view.checkedAt && !Number.isNaN(Date.parse(view.checkedAt)));

    // the key never reaches the browser and run ids are not exposed
    assert.ok(!JSON.stringify(started.json).includes(KEY));
    assert.ok(!all.includes(KEY));
    assert.ok(!/run_\d{4}/.test(all));

    // what we sent to the Agent API
    const posts = mock.log.filter((e) => e.method === 'POST');
    assert.ok(posts.length >= 6, 'three board runs plus checks');
    for (const e of posts) {
      assert.equal(e.key, KEY);
      assert.ok(ALL_DOMAINS.has(new URL(e.body.url).hostname), e.body.url);
      assert.ok(e.body.agent_config.max_duration_seconds > 0);
      assert.equal(e.body.browser_profile, 'lite');
      assert.ok(!('use_vault' in e.body) && !('use_profile' in e.body), 'never logs in');
    }
    const wwr = posts.find((e) => e.body.url.includes('weworkremotely.com/remote-jobs/search'));
    assert.ok(wwr.body.url.includes('term=Product%20Manager'));
    assert.ok(wwr.body.goal.includes('START_TITLE\nAssociate Product Manager\nEND_TITLE'));
  } finally {
    mock.server.close();
  }
});

test('a fully successful search is cached and a repeat starts no new runs', async () => {
  const mock = await startMock({ jobicyOk: true });
  process.env.TINYFISH_BASE_URL = mock.url;
  try {
    const first = await call(search, { title: 'Product Associate' });
    assert.equal(first.status, 202);
    const done = await runToCompletion(first.json.jobId);
    assert.ok(done.json.boards.every((b) => b.status === 'done'));
    const before = mock.log.filter((e) => e.method === 'POST').length;

    // same title with different capitalisation and spacing hits the cache
    const second = await call(search, { title: '  product   associate ' });
    assert.equal(second.status, 200);
    assert.equal(second.json.cached, true);
    assert.equal(second.json.phase, 'done');
    assert.equal(second.json.listings.length, done.json.listings.length);
    assert.equal(mock.log.filter((e) => e.method === 'POST').length, before, 'no new runs');
  } finally {
    mock.server.close();
  }
});

test('a search where a board failed is not cached', async () => {
  const mock = await startMock();
  process.env.TINYFISH_BASE_URL = mock.url;
  try {
    const first = await call(search, { title: 'Data Analyst' });
    await runToCompletion(first.json.jobId);
    const second = await call(search, { title: 'Data Analyst' });
    assert.equal(second.status, 202, 'ran again instead of serving a partial result');
  } finally {
    mock.server.close();
  }
});

test('input validation rejects markup and junk', async () => {
  for (const title of ['<script>alert(1)</script>', 'a', '', 'x'.repeat(80), 'a"b', 42, null, undefined]) {
    const r = await call(search, { title });
    assert.equal(r.status, 400, JSON.stringify(title));
    assert.ok(r.json.error);
  }
  const bad = await call(status, { jobId: '../../etc/passwd' });
  assert.equal(bad.status, 400);
  const missing = await call(status, { jobId: 'a'.repeat(32) });
  assert.equal(missing.status, 404);
});

test('only POST, only JSON, only same origin', async () => {
  const get = await new Promise((resolve) => {
    const req = { method: 'GET', headers: { host: 'localhost' } };
    const res = { statusCode: 200, headers: {}, setHeader(k, v) { this.headers[k] = v; }, end(s) { resolve({ status: this.statusCode, json: JSON.parse(s) }); } };
    search(req, res);
  });
  assert.equal(get.status, 405);
  const cross = await call(search, { title: 'Designer' }, { headers: { origin: 'https://evil.example.com' } });
  assert.equal(cross.status, 403);
  const notJson = await call(search, { title: 'Designer' }, { headers: { 'content-type': 'text/plain' } });
  assert.equal(notJson.status, 415);
});

test('per-IP rate limit blocks the 4th search in an hour', async () => {
  const mock = await startMock({ queueStatus: 429 });
  process.env.TINYFISH_BASE_URL = mock.url;
  try {
    const codes = [];
    for (const t of ['One', 'Two', 'Three', 'Four']) {
      codes.push((await call(search, { title: t }, { ip: '198.51.100.9' })).status);
    }
    assert.deepEqual(codes.slice(0, 3).every((c) => c !== 429), true);
    assert.equal(codes[3], 429);
    // a different visitor is not blocked by that
    const other = await call(search, { title: 'Five' }, { ip: '198.51.100.10' });
    assert.notEqual(other.status, 429);
    // the response tells them when to retry
    const blocked = await call(search, { title: 'Six' }, { ip: '198.51.100.9' });
    assert.ok(Number(blocked.headers['retry-after']) > 0);
  } finally {
    mock.server.close();
  }
});

test('daily run cap stops spending', async () => {
  const mock = await startMock();
  process.env.TINYFISH_BASE_URL = mock.url;
  process.env.DAILY_RUN_CAP = '2';
  try {
    const r = await call(search, { title: 'Support Specialist' });
    assert.equal(r.status, 503);
    assert.match(r.json.error, /budget/i);
    assert.equal(mock.log.filter((e) => e.method === 'POST').length, 0, 'no runs were started');
  } finally {
    mock.server.close();
  }
});

test('Mino errors become clear messages, not crashes', async () => {
  const cases = [
    [402, /budget/i],
    [429, /busy/i],
    [401, /not set up/i],
    [500, /problem|reached/i],
  ];
  for (const [code, pattern] of cases) {
    store.resetMemoryForTests();
    const mock = await startMock({ queueStatus: code });
    process.env.TINYFISH_BASE_URL = mock.url;
    try {
      const r = await call(search, { title: `Role ${code}` });
      assert.equal(r.status, 502, String(code));
      assert.match(r.json.error, pattern, String(code));
      assert.ok(!JSON.stringify(r.json).includes(KEY));
    } finally {
      mock.server.close();
    }
  }
});

test('a Mino timeout becomes a clear message', async () => {
  const mock = await startMock({ hang: true });
  process.env.TINYFISH_BASE_URL = mock.url;
  process.env.MINO_TIMEOUT_MS = '150';
  try {
    const r = await call(search, { title: 'Timeout Role' });
    assert.equal(r.status, 502);
    assert.match(r.json.error, /too long/i);
  } finally {
    mock.server.close();
  }
});

test('production refuses to run without a durable store', async () => {
  process.env.NODE_ENV = 'production';
  const r = await call(search, { title: 'Designer' });
  assert.equal(r.status, 503);
  assert.match(r.json.error, /not fully set up/i);
});

test('missing API key gives a setup message and leaks nothing', async () => {
  const saved = process.env.TINYFISH_API_KEY;
  delete process.env.TINYFISH_API_KEY;
  try {
    const r = await call(search, { title: 'Designer' });
    assert.equal(r.status, 503);
    assert.ok(!r.text.includes('TINYFISH'));
  } finally {
    process.env.TINYFISH_API_KEY = saved;
  }
});
