'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');

const { isAllowedUrl, cleanUrl } = require('../lib/allowlist');
const { cleanTitleInput, cleanText } = require('../lib/sanitize');
const { parsePosted } = require('../lib/posted');
const { assessPay } = require('../lib/pay');
const { normalizeFacts, scoreTrust } = require('../lib/trust');
const { coreTerm, buildListingGoal, BOARDS } = require('../lib/boards');

test('allowlist accepts approved https board URLs', () => {
  assert.equal(isAllowedUrl('https://weworkremotely.com/remote-jobs/x'), true);
  assert.equal(isAllowedUrl('https://www.workingnomads.com/jobs/y'), true);
  assert.equal(isAllowedUrl('https://jobicy.com/jobs/1-z'), true);
});

test('allowlist rejects everything else', () => {
  const bad = [
    'http://weworkremotely.com/x',
    'https://weworkremotely.com.evil.com/x',
    'https://evil.com/weworkremotely.com',
    'https://weworkremotely.com@evil.com/x',
    'https://user:pw@weworkremotely.com/x',
    'https://weworkremotely.com:8443/x',
    'https://weworkremotely.com./x',
    'javascript:alert(1)',
    'file:///etc/passwd',
    'https://169.254.169.254/latest/meta-data',
    'https://localhost/x',
    '',
    null,
    undefined,
    42,
  ];
  for (const u of bad) assert.equal(isAllowedUrl(u), false, String(u));
});

test('cleanUrl drops fragments and enforces per-board domains', () => {
  assert.equal(cleanUrl('https://jobicy.com/jobs/1#apply'), 'https://jobicy.com/jobs/1');
  assert.equal(cleanUrl('https://jobicy.com/jobs/1', ['weworkremotely.com']), null);
});

test('title input is validated', () => {
  assert.equal(cleanTitleInput('Associate Product Manager').ok, true);
  assert.equal(cleanTitleInput("Customer Success (EMEA) - C++ / Sales Eng.").ok, true);
  for (const bad of ['', ' ', 'a', 'x'.repeat(61), '<script>alert(1)</script>', 'a"b', 'line1\nline2 <b>', null, 12, {}]) {
    const r = cleanTitleInput(bad);
    if (bad === 'line1\nline2 <b>') assert.equal(r.ok, false);
    else assert.equal(r.ok, false, JSON.stringify(bad));
  }
});

test('scraped text is cleaned', () => {
  assert.equal(cleanText('<img src=x onerror=alert(1)>Product Analyst'), 'Product Analyst');
  for (const nasty of ['<scr<script>ipt>alert(1)</scr</script>ipt>', '<<b>b>x</b>', '<a href="javascript:alert(1)">hi</a>']) {
    const out = cleanText(nasty);
    assert.ok(!/[<>]/.test(out), nasty);
  }
  assert.ok(!/[<>]/.test(cleanText('a < b > c')));
  assert.equal(cleanText('Product Manager \u2013 Anti Fraud'), 'Product Manager - Anti Fraud');
  assert.equal(cleanText('USD 200k\u2014232k'), 'USD 200k-232k');
  assert.equal(cleanText('a\u202Eb\u200Bc'), 'a b c');
  assert.equal(cleanText('   '), null);
  assert.equal(cleanText({}), null);
  assert.ok(cleanText('x'.repeat(500), 50).length <= 50);
});

test('posted dates are parsed', () => {
  const now = Date.UTC(2026, 9, 24, 15);
  const h = 3600000;
  assert.equal(parsePosted('9 hours ago', now), now - 9 * h);
  assert.equal(parsePosted('3d', now), now - 72 * h);
  assert.equal(parsePosted('2 weeks ago', now), now - 14 * 24 * h);
  assert.equal(new Date(parsePosted('Oct 24', now)).getUTCDate(), 24);
  assert.equal(new Date(parsePosted('Dec 30', now)).getUTCFullYear(), 2025);
  assert.equal(new Date(parsePosted('2026-10-20', now)).getUTCDate(), 20);
  assert.equal(parsePosted('whenever', now), null);
  assert.equal(parsePosted(null, now), null);
  assert.equal(parsePosted('2027-01-01', now), null);
});

test('pay assessment', () => {
  assert.equal(assessPay(null, 'x').status, 'missing');
  assert.equal(assessPay('Competitive', 'x').status, 'missing');
  assert.equal(assessPay('USD 230k/year', 'Senior PM').status, 'ok');
  assert.equal(assessPay('$47k-$52k per year', 'x').status, 'ok');
  assert.equal(assessPay('$900 per hour', 'x').status, 'unrealistic');
  assert.equal(assessPay('EUR 400k/year', 'Associate Product Manager').status, 'unrealistic');
  assert.equal(assessPay('Earn $5,000 a week, no experience needed', 'Typist').status, 'unrealistic');
});

const good = {
  company_name: 'Acme',
  company_website_domain: 'acme.com',
  has_company_profile_on_this_site: true,
  apply_method: 'board_apply_button',
  apply_email_domain: null,
  pay_text: '$60k per year',
  asks_for_payment: false,
  asks_for_personal_documents: false,
  evidence: null,
};

test('trust labels', () => {
  const f = (over) => normalizeFacts({ ...good, ...over });
  assert.equal(scoreTrust(f({}), { title: 'APM' }).label, 'Looks fine');
  assert.equal(scoreTrust(f({ asks_for_payment: true }), { title: 'APM' }).label, 'Likely scam');
  assert.equal(scoreTrust(f({ asks_for_personal_documents: true }), { title: 'APM' }).label, 'Likely scam');
  assert.equal(
    scoreTrust(f({ apply_method: 'messaging_app', pay_text: '$900 per hour' }), { title: 'APM' }).label,
    'Likely scam'
  );
  assert.equal(
    scoreTrust(f({ company_website_domain: null, has_company_profile_on_this_site: false }), { title: 'APM' }).label,
    'Check first'
  );
  assert.equal(
    scoreTrust(f({ apply_method: 'email', apply_email_domain: 'gmail.com' }), { title: 'APM' }).label,
    'Check first'
  );
  assert.equal(scoreTrust(f({ pay_text: null }), { title: 'APM' }).label, 'Looks fine');
  assert.equal(scoreTrust(f({ company_website_domain: 'linktr.ee', has_company_profile_on_this_site: false }), {}).label, 'Check first');
  // keyword layer catches a fee even if the model missed it
  assert.equal(
    scoreTrust(f({ evidence: 'You must pay a registration fee to start' }), { title: 'APM' }).label,
    'Likely scam'
  );
  assert.equal(scoreTrust(f({ evidence: 'Paid via direct deposit' }), { title: 'APM' }).label, 'Looks fine');
});

test('reasons are one line and contain no dashes that look like em dashes', () => {
  const r = scoreTrust(normalizeFacts({ ...good, asks_for_payment: true, apply_method: 'messaging_app' }), {});
  assert.ok(!r.reason.includes('\n'));
  assert.ok(!/[\u2013\u2014]/.test(r.reason));
});

test('unusable check results are rejected', () => {
  assert.equal(normalizeFacts(null), null);
  assert.equal(normalizeFacts([]), null);
  assert.equal(normalizeFacts({ status: 'failure' }), null);
  assert.equal(normalizeFacts({ hello: 'world' }), null);
});

test('goal text keeps the title between markers and has no dashes', () => {
  const goal = buildListingGoal(BOARDS[0], 'Associate Product Manager', 8);
  assert.ok(goal.includes('START_TITLE\nAssociate Product Manager\nEND_TITLE'));
  assert.ok(!/[\u2013\u2014]/.test(goal));
  assert.equal(coreTerm('Associate Product Manager'), 'Product Manager');
  assert.equal(coreTerm('Senior Data Analyst'), 'Data Analyst');
});
