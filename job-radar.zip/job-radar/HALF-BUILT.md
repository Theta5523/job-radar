# What is half built or not verified

Read this before the demo. These are the honest answers if someone asks.

## Not verified yet

- **The deployed app has not been run against the real Agent API.** I tested the app against a fake agent that follows the documented request and response shapes, and I ran the same goals by hand against the real boards through the TinyFish tools. The first full run of this code with a real key happens on your machine. Expect to fix small things.
- **It has not been deployed to Vercel.** The setup follows Vercel's standard layout (`public/` plus `api/`), but I could not test a deploy from here.
- **Never run with a real Redis database.** Tests use the in-memory store. The Redis calls use the `@upstash/redis` library in the usual way but are untested here.
- **The look has not been seen in a real browser or on a phone.** The page was built mobile first and its behavior is tested in a simulated browser, but I have no screenshots.
- **Cost per search is only an estimate.** The agent bills $0.016 per step. Board runs took 6 to 8 steps in my tests, but I did not measure the trust check runs. A full search is roughly $0.50 to $1.00. A run that gets stuck can take around 20 steps (about $0.32) before it times out. The default `DAILY_RUN_CAP` of 40 limits the site to about $3 to $4 a day. Check your TinyFish usage after the first real searches and adjust.

## Product limits

- **Three boards, not four.** Himalayas blocks automated access. Remotive's robots.txt disallows job pages and hides company names. Remote OK's product manager page was stale. Remote.co blocks bots. Adding a board is a small config change.
- **The trust check never visits the company's own website.** To keep the "approved domains only" rule strict, it reads the posting and the board's own company page. So "company website listed" means a plausible website is shown, not that the site loads or matches the company.
- **Only the newest 10 listings get a trust check.** The rest show "Not checked" to keep costs down.
- **Labels come from simple rules I wrote, not from a trained model.** Weights and cut offs are untuned, there is no accuracy number, and wrong labels in both directions should be expected.
- **Pay checks are crude.** No currency conversion and no knowledge of what a role normally pays in a given country.
- **Search relevance depends on the agent.** It decides what counts as related and skips roles that look too senior. Some searches return few results or none. "Associate" titles are the hardest.
- **Dates are approximate.** Boards show "3d" or "9 hours ago". Sorting uses an estimate. Listings with no readable date go last.
- **The agent's output is checked by our code, not enforced by a schema.** The `output_schema` option is account gated, so bad items are dropped after the fact.
- **No pagination, filters, saved searches, alerts or accounts.** Deliberate for an MVP.

## Security limits

- **Per IP limits can be dodged with many addresses.** The daily run cap is the real protection for your credits.
- **The agent can click around inside a board.** We only allow the board URLs we send and accept links on the same board back, but the agent is held to staying on the site by its instructions, not by a technical block.
- **Prompt injection is reduced, not eliminated.** A hostile posting could still try to steer the agent. The design limits the damage: the agent has no logins, outputs are validated and cleaned, and the label is decided by our own code.
- **Vercel keeps its own request logs** (time, path, address). The app does not log searches, but the host does. Say so honestly.
- **Board terms of service were not reviewed.** I checked robots.txt on October 25, 2026. Read each board's terms yourself before a public launch.

## Pages and content

- **Privacy and Terms are plain language drafts, not legal advice.** Have someone qualified review them before a public launch. They name no jurisdiction.
- **The contact email on both pages is a public address.** It is already filled in. Change it in `public/privacy.html` and `public/terms.html` if you prefer another.
- **No custom domain and no error monitoring set up.**
- **Mock mode (`npm run dev:mock`) shows fake data.** Do not use it for the demo.
