'use strict';

(function () {
  var POLL_MS = 4000;
  var MAX_WAIT_MS = 9 * 60 * 1000;
  var TRUST_KEY = {
    'Looks fine': 'fine',
    'Check first': 'check',
    'Likely scam': 'scam',
    'Not checked': 'none',
    Checking: 'none',
  };

  var form = document.getElementById('search-form');
  var input = document.getElementById('title');
  var button = document.getElementById('search-button');
  var errorBox = document.getElementById('error');
  var statusBox = document.getElementById('status');
  var results = document.getElementById('results');
  var resultsMeta = document.getElementById('results-meta');
  var jobsList = document.getElementById('jobs');

  var session = 0;

  function el(tag, className, text) {
    var node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined && text !== null) node.textContent = text;
    return node;
  }

  function sleep(ms) {
    return new Promise(function (resolve) { setTimeout(resolve, ms); });
  }

  async function postJson(path, body) {
    var res = await fetch(path, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    var data = null;
    try { data = await res.json(); } catch (e) { data = null; }
    if (!res.ok) {
      var err = new Error((data && data.error) || 'Something went wrong. Please try again.');
      err.status = res.status;
      throw err;
    }
    return data;
  }

  function showError(message) {
    errorBox.textContent = message;
    errorBox.hidden = false;
  }

  function clearError() {
    errorBox.textContent = '';
    errorBox.hidden = true;
  }

  function setBusy(busy) {
    button.disabled = busy;
    button.textContent = busy ? 'Searching...' : 'Search boards';
  }

  function boardStateText(board) {
    if (board.status === 'running') return 'reading now';
    if (board.status === 'done') {
      return board.count === 1 ? '1 listing found' : board.count + ' listings found';
    }
    return board.error || 'could not be read';
  }

  function renderStatus(view) {
    statusBox.textContent = '';
    var line = 'Reading the boards.';
    if (view.phase === 'checking') line = 'Checking each posting for scam signs.';
    if (view.phase === 'done') line = 'Finished.';
    statusBox.appendChild(el('p', 'status-line', line));

    var list = el('ul', 'boards');
    (view.boards || []).forEach(function (board) {
      var item = el('li');
      item.appendChild(el('strong', null, board.name));
      item.appendChild(el('span', 'state', ': ' + boardStateText(board)));
      list.appendChild(item);
    });
    statusBox.appendChild(list);
  }

  function addFact(dl, label, value) {
    if (!value) return;
    dl.appendChild(el('dt', null, label));
    dl.appendChild(el('dd', null, value));
  }

  function flash(btn, text) {
    var original = btn.textContent;
    btn.textContent = text;
    setTimeout(function () { btn.textContent = original; }, 2000);
  }

  async function copyLink(link, btn) {
    try {
      await navigator.clipboard.writeText(link);
      flash(btn, 'Copied');
    } catch (e) {
      var area = document.createElement('textarea');
      area.value = link;
      area.setAttribute('readonly', '');
      area.className = 'skip';
      document.body.appendChild(area);
      area.select();
      var ok = false;
      try { ok = document.execCommand('copy'); } catch (e2) { ok = false; }
      document.body.removeChild(area);
      flash(btn, ok ? 'Copied' : 'Copy failed');
    }
  }

  function renderJob(job) {
    var item = el('li', 'job');
    item.setAttribute('data-trust', TRUST_KEY[job.trust.label] || 'none');

    var verdict = el('p', 'verdict');
    verdict.appendChild(el('strong', null, job.trust.label + '.'));
    verdict.appendChild(document.createTextNode(' ' + job.trust.reason));
    item.appendChild(verdict);

    item.appendChild(el('h3', 'job-title', job.title));

    var facts = el('dl', 'facts');
    addFact(facts, 'Company', job.company);
    addFact(facts, 'Posted', job.posted);
    addFact(facts, 'Pay', job.pay || 'Not shown');
    addFact(facts, 'Board', job.board);
    item.appendChild(facts);

    var actions = el('div', 'actions');
    if (/^https:\/\//.test(job.link)) {
      var open = el('a', 'btn', 'Open posting');
      open.href = job.link;
      open.target = '_blank';
      open.rel = 'noopener noreferrer nofollow';
      actions.appendChild(open);

      var copy = el('button', 'btn btn-secondary', 'Copy link');
      copy.type = 'button';
      copy.addEventListener('click', function () { copyLink(job.link, copy); });
      actions.appendChild(copy);
    }
    item.appendChild(actions);
    return item;
  }

  function renderResults(view) {
    var listings = view.listings || [];
    if (listings.length === 0 && view.phase !== 'done') {
      results.hidden = true;
      return;
    }
    results.hidden = false;
    jobsList.textContent = '';
    resultsMeta.textContent = '';

    if (listings.length === 0) {
      resultsMeta.textContent = 'No matching listings were found on the boards that answered. Try a shorter title, like "product manager".';
      return;
    }

    var parts = [listings.length === 1 ? '1 listing, newest first.' : listings.length + ' listings, newest first.'];
    if (view.checkedAt) {
      var when = new Date(view.checkedAt);
      if (!isNaN(when.getTime())) {
        parts.push('Last checked ' + when.toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' }) + '.');
      }
    } else {
      parts.push('Checks are still running.');
    }
    if (view.cached) parts.push('Shown from a recent identical search.');
    resultsMeta.textContent = parts.join(' ');

    listings.forEach(function (job) { jobsList.appendChild(renderJob(job)); });
  }

  function render(view) {
    renderStatus(view);
    renderResults(view);
  }

  async function runSearch(title) {
    var mine = ++session;
    clearError();
    results.hidden = true;
    jobsList.textContent = '';
    statusBox.textContent = '';
    setBusy(true);

    var started;
    try {
      started = await postJson('/api/search', { title: title });
    } catch (err) {
      showError(err.message);
      setBusy(false);
      return;
    }
    render(started);
    if (started.cached || started.phase === 'done') {
      setBusy(false);
      return;
    }

    var begun = Date.now();
    var failures = 0;
    while (mine === session) {
      await sleep(POLL_MS);
      if (mine !== session) return;
      if (Date.now() - begun > MAX_WAIT_MS) {
        showError('This is taking longer than expected. Please run the search again.');
        break;
      }
      try {
        var view = await postJson('/api/status', { jobId: started.jobId });
        failures = 0;
        render(view);
        if (view.phase === 'done') break;
      } catch (err) {
        if (err.status === 400 || err.status === 404 || err.status === 429) {
          showError(err.message);
          break;
        }
        failures += 1;
        if (failures >= 3) {
          showError('Lost the connection to the server. Please run the search again.');
          break;
        }
      }
    }
    if (mine === session) setBusy(false);
  }

  form.addEventListener('submit', function (event) {
    event.preventDefault();
    var title = input.value.replace(/\s+/g, ' ').trim();
    if (title.length < 2) {
      showError('Enter a job title of at least 2 characters.');
      input.focus();
      return;
    }
    runSearch(title);
  });
})();
